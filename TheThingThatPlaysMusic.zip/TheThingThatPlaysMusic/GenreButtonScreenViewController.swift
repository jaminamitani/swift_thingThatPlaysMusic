import UIKit
import MediaPlayer

class GenreButtonScreenViewController: UIViewController {
    //intialization of aple music controller, grants access to inbuilt functionality dealing with apple music
    var musicPlayer = MPMusicPlayerController.applicationMusicPlayer
    
   override func viewDidLoad() {
        super.viewDidLoad()
        gifImage.loadGif(name: "berniaDeer")
    }
    //reference to image background
    @IBOutlet weak var gifImage: UIImageView!
    
    override func didReceiveMemoryWarning() {
            super .didReceiveMemoryWarning()
    }
    
    
    @IBAction func genreButtonTapped(_ sender: UIButton) {
        //ask for authorization to access music library
        MPMediaLibrary.requestAuthorization{(status) in
            //if granted access
            if status == .authorized {
                self.playerGenre(genre: sender.currentTitle!)
            }
        }
    }
    
    // when "||" button is pressed
    @IBAction func stopButton(_ sender: UIButton) {
        musicPlayer.stop()
    }
    
    //when ">>" button is pressed
    @IBAction func nextButton(_ sender: UIButton) {
        musicPlayer.skipToNextItem()
    }
    
    
    //function that filters the songs in the library by genres
    func playerGenre(genre: String){
        musicPlayer.stop(); //stops the music first

        //searches the music library
        let query = MPMediaQuery();
        //creates a filter of "genre"
        let predicate = MPMediaPropertyPredicate(value: genre, forProperty: MPMediaItemPropertyGenre)
        
        //applying the filter to library
        query.addFilterPredicate(predicate)
        //putting the filtered music in queue
        musicPlayer.setQueue(with: query)
        //shuffling the queue
        musicPlayer.shuffleMode = .songs
        //playing the music
        musicPlayer.play()
    }
}
